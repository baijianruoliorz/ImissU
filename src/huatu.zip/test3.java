package huatu;

/**
 * @author liqiqi_tql
 * @date 2020/6/16 -18:29
 */
public class test3 {

    public static void main(String args[]){

        new win();

    }

}
